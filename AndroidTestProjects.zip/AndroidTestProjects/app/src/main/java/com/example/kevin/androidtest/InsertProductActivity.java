package com.example.kevin.androidtest;

import android.support.v7.app.AppCompatActivity;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;

public class InsertProductActivity extends AppCompatActivity {

    private EditText insertName, insertPrice;
    private Button insertProduct;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_insert_product);

        //intancia de vistas
        insertName = findViewById(R.id.inputProductName);
        insertPrice = findViewById(R.id.inputProductPrice);
        insertProduct = findViewById(R.id.insertProductButton);

        //listener para el botton
        insertProduct.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                insertProduct();
            }
        });

    }

    //metodo para agregar el producto
    private void insertProduct() {
        //obtenemos los datos que escribio el usuario
        String name = insertName.getText().toString().trim();
        double price = Double.parseDouble(insertPrice.getText().toString().trim());

        //validamos el formulario
        if (name.isEmpty()) {
            insertName.setError("Este campo no puede estar vacío");
            insertName.requestFocus();
            return;
        }

        if (price <= 0) {
            insertPrice.setError("Ingrese un precio válido");
            insertPrice.requestFocus();
            return;
        }

        //creamos el producto hecho por el usuario
        Product product = new Product(name, price);

        //una vez validados los datos, insertamos el producto del usuario
        MainActivity.dataBaseBuild().productDao().insertProduct();

        //finalmente se cierra la actividad
        InsertProductActivity.this.finish();

    }
}
