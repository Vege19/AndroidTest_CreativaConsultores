package com.example.kevin.androidtest;

import java.util.List;

import androidx.room.Dao;
import androidx.room.Insert;
import androidx.room.Query;

@Dao
public interface ProductDao {

    //metodos para crud de la base de datos

    //Obtener todos los productos
    @Query("SELECT * FROM product")
    List<Product> getProducts();

    //Insertar un producto
    @Insert
    void insertProduct(Product... products);

    //Editar un producto
    @Query("UPDATE product SET product_name = :name, product_price = :price WHERE id = :id")
    void updateProduct(String name, double price, int id);

}
